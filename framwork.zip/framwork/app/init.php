<?php
require_once("app.php");
require_once("Controller.php");
require_once("Model.php");
require_once("View.php");
// require_once"vendor/autoload.php";
// require_once"database.php";
// require_once"service/UserService.php";

$obj=new App;

?>