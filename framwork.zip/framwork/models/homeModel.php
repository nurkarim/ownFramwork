<?php
/**
* 
*/
class HomeModel 
{
	
	function __construct()
	{
		# code...
	}
}
?>