<?php
define("URL", "http://localhost/framwork/")

?>