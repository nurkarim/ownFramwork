<?php
session_start();
require_once("config/baseUrl.php");
require_once("app/init.php");

?>